
# WhatsApp Dify Bot

Bot integrado ao WhatsApp e ao Dify AI, hospedado no Railway.

## Instalação
```
npm install
```

## Execução local
```
npm start
```

## Webhook
Certifique-se de definir o token de verificação no Meta/Facebook como:
```
difybot123
```
